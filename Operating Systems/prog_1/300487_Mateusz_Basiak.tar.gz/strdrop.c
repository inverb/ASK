int strdrop(char *str, const char *set) {
  return 0;
}
